/**
 *Kristopher Kuenning
 *12/7/2025
 *Module 9
 *CSD430
 */

package csd430;

import java.io.Serial;
import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MovieBean - JavaBean representing a movie record.
 * Handles inserting, reading, updating, and deleting movie data.
 */
public class MovieBean implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    // JDBC connection info
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/CSD430";
    private static final String DB_USER   = "student1";
    private static final String DB_PASS   = "pass";

    // Your table name
    private static final String TABLE_NAME = "kristopher_movies_data";

    // Fields matching the DB table
    private int movieId;
    private String title;
    private int releaseYear;
    private String genre;
    private String director;
    private double rating;
    public MovieBean() {}

    // Getters and setters
    public int getMovieId() { return movieId; }
    public void setMovieId(int movieId) { this.movieId = movieId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getReleaseYear() { return releaseYear; }
    public void setReleaseYear(int releaseYear) { this.releaseYear = releaseYear; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    /** Return all movie records as a List of MovieBean objects. */
    public static List<MovieBean> getAllMovies() throws Exception {
        List<MovieBean> movies = new ArrayList<>();

        Class.forName("com.mysql.cj.jdbc.Driver");

        String sql = "SELECT movie_id, title, release_year, genre, director, rating "
                + "FROM " + TABLE_NAME + " ORDER BY movie_id";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MovieBean m = new MovieBean();
                m.setMovieId(rs.getInt("movie_id"));
                m.setTitle(rs.getString("title"));
                m.setReleaseYear(rs.getInt("release_year"));
                m.setGenre(rs.getString("genre"));
                m.setDirector(rs.getString("director"));
                m.setRating(rs.getDouble("rating"));
                movies.add(m);
            }
        }

        return movies;
    }

    // ------------------ NEW METHOD for this module ------------------

    /**
     * Delete a movie record from the database using its primary key.
     *
     * @param id primary key value (movie_id) of the record to delete
     */
    public static void deleteById(int id) throws Exception {
        // Load JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        String sql = "DELETE FROM " + TABLE_NAME + " WHERE movie_id = ?";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}