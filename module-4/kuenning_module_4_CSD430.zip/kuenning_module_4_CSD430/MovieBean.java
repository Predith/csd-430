// Kristopher Kuenning
//11/9/2025
//CSD-430
//Module 4 Assignment - JavaBean

import java.io.Serializable;

public class MovieBean implements Serializable {
    private static final long serialVersionUID = 1L;

    // ===== Core fields (edit as needed) =====
    private String title;
    private int year;
    private String director;
    private String genre;
    private int runtimeMinutes;
    private String whereWatched;
    private String favoriteScene;
    private double ratingOutOf10;
    private String imdbLink;
    private String posterUrl;

    /** No-arg constructor (required for a JavaBean) */
    public MovieBean() {}

    // ===== Getters & Setters =====
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public int getRuntimeMinutes() { return runtimeMinutes; }
    public void setRuntimeMinutes(int runtimeMinutes) { this.runtimeMinutes = runtimeMinutes; }

    public String getWhereWatched() { return whereWatched; }
    public void setWhereWatched(String whereWatched) { this.whereWatched = whereWatched; }

    public String getFavoriteScene() { return favoriteScene; }
    public void setFavoriteScene(String favoriteScene) { this.favoriteScene = favoriteScene; }

    public double getRatingOutOf10() { return ratingOutOf10; }
    public void setRatingOutOf10(double ratingOutOf10) { this.ratingOutOf10 = ratingOutOf10; }

    public String getImdbLink() { return imdbLink; }
    public void setImdbLink(String imdbLink) { this.imdbLink = imdbLink; }

    public String getPosterUrl() { return posterUrl; }
    public void setPosterUrl(String posterUrl) { this.posterUrl = posterUrl; }
}
