/**
 *Kristopher Kuenning
 *11/23/2025
 *Module 7
 *CSD430
 */

package csd430;

import java.io.Serial;
import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MovieBean - JavaBean representing a movie record.
 * Handles inserting and reading movie data from the database.
 */
public class MovieBean implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    // JDBC connection info
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/CSD430";
    private static final String DB_USER   = "student1";
    private static final String DB_PASS   = "pass";

    // YOUR EXACT TABLE NAME
    private static final String TABLE_NAME = "kristopher_movies_data";

    // Fields matching the DB table
    private int movieId;
    private String title;
    private int releaseYear;
    private String genre;
    private String director;
    private double rating;

    public MovieBean() {}

    // Getters & setters
    public int getMovieId() { return movieId; }
    public void setMovieId(int movieId) { this.movieId = movieId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getReleaseYear() { return releaseYear; }
    public void setReleaseYear(int releaseYear) { this.releaseYear = releaseYear; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    /**
     * Inserts this MovieBean into the database.
     */
    public void insert() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");

        String sql = "INSERT INTO " + TABLE_NAME
                + " (title, release_year, genre, director, rating)"
                + " VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, this.title);
            ps.setInt(2, this.releaseYear);
            ps.setString(3, this.genre);
            ps.setString(4, this.director);
            ps.setDouble(5, this.rating);

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) this.movieId = rs.getInt(1);
            }
        }
    }

    /**
     * Returns a list of all movie records.
     */
    public static List<MovieBean> getAllMovies() throws Exception {
        List<MovieBean> movies = new ArrayList<>();

        Class.forName("com.mysql.cj.jdbc.Driver");

        String sql = "SELECT movie_id, title, release_year, genre, director, rating "
                + "FROM " + TABLE_NAME + " ORDER BY movie_id";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                MovieBean m = new MovieBean();
                m.setMovieId(rs.getInt("movie_id"));
                m.setTitle(rs.getString("title"));
                m.setReleaseYear(rs.getInt("release_year"));
                m.setGenre(rs.getString("genre"));
                m.setDirector(rs.getString("director"));
                m.setRating(rs.getDouble("rating"));
                movies.add(m);
            }
        }

        return movies;
    }
}
