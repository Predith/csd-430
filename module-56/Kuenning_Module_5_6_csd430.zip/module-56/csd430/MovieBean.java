/**
 *Kristopher Kuenning
 *11/16/2025
 *Module 5 & 6
 *CSD430
 */

package csd430;

import java.io.Serial;
import java.io.Serializable;

public class MovieBean implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private int movieId;
    private String title;
    private int releaseYear;
    private String genre;
    private String director;
    private double rating;

    // No-argument constructor (required for a bean)
    public MovieBean() {
    }

    // Getters and setters
    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
